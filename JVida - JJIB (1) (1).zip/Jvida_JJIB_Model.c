/*JVida_JJIB_Model.c
Beatriz Lopes Rizzo, Julia Gachido Schmidt, Joao Pedro Figols Neco, Isabella Rubio Venancio*/

#include "JVida_JJIB_Model.h"


