/* Jvida_JJIB_Projeto.c
Beatriz Lopes Rizzo, Julia Gachido Schmidt, Joao Pedro Figols Neco, Isabella Rubio Venancio*/

main() 
{
	tamanho();
	geraMatriz();
	inicializaMenu();
}
