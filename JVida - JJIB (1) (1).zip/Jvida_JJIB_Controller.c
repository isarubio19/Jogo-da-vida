/*Jvida_JJIB_Controller.h
Beatriz Lopes Rizzo, Julia Gachido Schmidt, Joao Pedro Figols Neco, Isabella Rubio Venancio*/

#include "JVida_JJIB_Model.h"
#include "JVida_JJIB_View.h"
#include <stdlib.h>
#include <stdio.h>

//funcao que gera a matriz do mundo
void geraMatriz()
{
	int i, j;
	for (i = 0; i < MAX; i++)
	{
		for (j = 0; j < MAX; j++)
		{
			vida[i][j] = '.';
		}
	}
}

//funcao que contem a logica do menu principal
void inicializaMenu()
{
	flag = 0;
	
	do
	{
		op = menuPrincipal();
		
		switch (op)
		{
			case 1:  //apresentar o mundo
			{
				geraVida();
				break;	
			}
			case 2:	 //limpar o mundo
			{
				geraMatriz();
				geraVida();
				limpaListaMorto();
				limpaListaVivo();	
				break;
			}
			case 3:  //criar celulas vivas
			{
				geraVida();
				coordCelula();
				break;	
			}
			case 4: //apresenta lista
			{
				mostraListVivo();
				mostraListMorto();
				break;
			}
			case 5:	//apresenta/remove celulas mortas
			{
				geraVida();
				break;
			}
			case 6: 
			{
				proxGeracao();
				mostraListGer();
				printf("deu bom??\n");
				teste();
				geraVida();
				break;	
			}
			case 7: //grava geracao inicial
			{
				gravaCelulas();
				mensagem(2);
				break;	
			}
			case 8: //recupera geracao inicial
			{
				recuperaCelulas();
				carregaMortosVizinhos();
				mensagem(3);
				break;	
			}
		}
	}
	while (op != 9);
}

//funcao que adiciova vivo
void carregaVivo(int ii, int jj)
{
	tipoCel *aux = malloc(sizeof(tipoCel));
	if (aux == NULL)
	{
		mensagem(1);
	}
	
	aux->lin = ii;
	aux->col = jj;

	if (totvivo == 0)
	{
		pvivo = aux;
		pvivo->next = NULL;
	}
	else
	{
		aux->next = pvivo;
		pvivo = aux;
	}
	totvivo++;	
}

//funcao que remove elementos da lista
void removeVivo(int ii, int jj)
{
	atual = pvivo;
	anterior = NULL;

	if (totvivo > 0)
	{	
		if (pvivo->lin == ii && pvivo->col == jj) //remove primeiro da lista (ultima celula inserida)
		{	
			pvivo = pvivo->next;
			free(atual);
		}
		else
		{
			while (atual->lin != ii || atual->col != jj) 
			{
				anterior = atual;
				atual = atual->next;
			}
			//elemento a ser removido sempre estara na lista
			anterior->next = atual->next;
			free(atual);	
		}			
	}
	totvivo--;
}

//permite a adicao de mortos na lista
void carregaMortosVizinhos()
{	
	int i, j;
	
	//limpa lista dos mortos (apenas se houver algo na lista)
	limpaListaMorto();
	
	//retira '+' da matriz 
	for (i = 0; i < dimensao; i++)
	{
		for (j = 0; j < dimensao; j++)
		{
			if (vida[i][j] == '+')
			{
				vida[i][j] = '.';
			}
		}
	}
	
	//percorre lista das celulas vivas para achar suas mortas vizinhas
	atual = pvivo;
	
	if (totvivo > 0)
	{
		if(atual->next == NULL) //so tem uma unica celula viva
		{
			descobreCoord(atual->lin, atual->col);
		}
		else
		{
			while (atual != NULL)
			{
				descobreCoord(atual->lin, atual->col);
				atual = atual->next;
			}
		}
	}
}	

//descobre as 8 coordenadas mortas de cada celula vizinha
void descobreCoord(int lin, int col)
{
	int k, j, morto;
	for (k = lin - 1; k <= lin + 1; k++) //linhas
	{
		for (j = col - 1; j <= col + 1; j++) //colunas
		{
			if(vida[k][j] != 'O' && k < dimensao && j < dimensao && k >= 0 && j >= 0 && totmorto == 0) //primeira celula adicionada
			{
				carrega1Morto(k, j);
			}
			else
			{
				morto = verifica1Morto(k, j);
				if (vida[k][j] != 'O' && k < dimensao && j < dimensao && k >= 0 && j >= 0 && morto != 1)
        		{
            		carrega1Morto(k, j);
        		}
			}
		}	
	}
}

//verifica se a celula ja esta na lista dos mortos
int verifica1Morto(int ii, int jj)
{
	atualMorto = pmorto;
		
	if (totmorto > 0)
	{
		while (atualMorto->next != NULL && (atualMorto->lin != ii || atualMorto->col != jj))
		{
			anteriorMorto = atualMorto;
			atualMorto = atualMorto->next;
		}
		if (atualMorto->lin == ii && atualMorto->col == jj)
		{
			return 1; //a celula ja existe na lista de mortos	
		}
		else
		{
			return 0;
		}
	}
}

//adiciona uma celula morta na lista 
void carrega1Morto (int ii, int jj)
{
	//cria lista de mortos
	auxMorto = malloc(sizeof(tipoCel));
	if (auxMorto == NULL)
	{
		mensagem(1);
	}
	
	auxMorto->lin = ii;
	auxMorto->col = jj;
	
	if (totmorto == 0)
	{
		pmorto = auxMorto;
		pmorto->next = NULL;
	}
	else
	{
		auxMorto->next = pmorto;
		pmorto = auxMorto;
		
	}
	vida[pmorto->lin][pmorto->col] = '+';
	totmorto++;
}


//limpa a lista dos vivos
void limpaListaVivo()
{
	while(totvivo != 0)
	{
		atual = pvivo;
		pvivo = pvivo->next;
		free(atual);
		totvivo--;
	}
}

//limpa a lista dos mortos
void limpaListaMorto()
{
	while (totmorto != 0 )
	{
		printf("entrou no totmorto?\n");
		atualMorto = pmorto;
		pmorto = pmorto->next;
		free(atualMorto);
		totmorto--;
	}
}
void limpaListaGeracao()
{
	tipoCel *aux;
	while (totgeracao != 0)
	{
		aux = pgeracao;
		pgeracao = pgeracao->next;
		free(aux);
		totgeracao--;
	}
}
//funcao que grava as celulas
void gravaCelulas()
{
	FILE*fp;
	int auxTotvivo;
	int i = 0;

	tipoCel *aux;
	aux = pvivo;
	auxTotvivo = totvivo;
	
	fp = fopen("CONFIG_INIC", "w");
	if((fp = fopen("CONFIG_INIC", "w")) == NULL)
	{
        printf("O arquivo CONFIG_INIC nao pode ser aberto.\n");
        return;
    }
        
    while(auxTotvivo != 0)
    {
		LConfig[i] = *aux;
		if(fwrite(&LConfig[i],sizeof(tipoCel),1,fp)!=1)
        {
            printf("\nErro na gravacao do arquivo CONFIG_INIC.\n");
            break;
        }
		aux = aux->next;
		i++;
		auxTotvivo--;
	}
	
	LConfig[i].next = NULL;
	fclose(fp);
}

//recupera as celulas
void recuperaCelulas()
{
	int i = 0;
	geraMatriz();
	limpaListaVivo();
	limpaListaMorto();

	FILE *fp;

	fp = fopen("CONFIG_INIC", "r");
	
	if((fp = fopen("CONFIG_INIC", "r")) == NULL)
    {
        printf("\nO arquivo CONFIG_INIC nao pode ser aberto\n");
        return;
    }
    
	do
    {
		if(fread(&LConfig[i],sizeof(tipoCel),1,fp)!=1)
        {
            printf("\nErro na leitura do arquivo CONFIG_INIC\n");
            break;
        }
	   
	   coord1 = LConfig[i].lin;
	   coord2 = LConfig[i].col;
	   vida[coord1][coord2] = 'O';	
	   carregaVivo(coord1, coord2);	   
	}
	while(LConfig[i].next != NULL);
	
	fclose(fp);
}

void proxGeracao()
{	
	int linhaMorto, colunaMorto, cont, auxvivo;
	int auxMorto = totmorto;
	tipoCel *auxpmorto = pmorto;
	while(auxMorto != 0 )
	{
		cont = 0;
		atualMorto = auxpmorto;
		atual = pvivo;
		linhaMorto = atualMorto->lin;
		colunaMorto = atualMorto->col;
		printf("%d, %d\n", linhaMorto, colunaMorto);
		auxvivo = totvivo;
		printf("%d\n", auxMorto);
		while (auxvivo != 0)
		{
			printf("socorro\n");
			printf("%d %d\n", atual->lin, atual->col);
			if ((linhaMorto - 1 == atual->lin ||linhaMorto + 1 == atual->lin ||linhaMorto == atual->lin) && (colunaMorto == atual->col ||colunaMorto - 1 == atual->col ||colunaMorto + 1 == atual->col))
			{
				cont++;
				printf("cont = %d\n", cont);
			}
			printf("oi\n");
			atual = atual->next;
			printf("oi2\n");
			auxvivo--;
			printf("auxvivo  %d\n",auxvivo);
		}
		if (cont == 3)
		{
			printf("Entrei\n");
			carregaGeracao(linhaMorto, colunaMorto);
			printf("carreguei??");
			vida[linhaMorto][colunaMorto] = 'O';
//			carregaMortosVizinhos();
		}
		printf("oi3\n");
		auxpmorto = auxpmorto->next;
		printf("oi4\n");
		auxMorto--;
		printf("%d\n", auxMorto);
	}
	
	
	printf("--------------------------------------\n");
	
//	while (auxvivo != 0)
//	{
		
		auxvivo = totvivo;
		int auxvivoDentro = totvivo;
		atual = pvivo;
		while (auxvivoDentro != 0)
		{
			auxvivo = totvivo;
			cont = 0;
			
			tipoCel *aux1 = pvivo;
			tipoCel *aux2 = aux1;
			while (aux2->next != NULL)
			{
				printf("auxvivo  depois %d\n",auxvivo);
				printf("Cel a ser comparada %d %d\n", atual->lin, atual->col);
				printf("Celulas seguintes %d %d\n", aux1->lin, aux1->col);
				
				if ((aux1->lin - 1 == atual->lin || aux1->lin + 1 == atual->lin || aux1->lin == atual->lin) && ( aux1->col == atual->col || aux1->col - 1 == atual->col ||aux1->col + 1 == atual->col ) && (aux1->lin != atual->lin || aux1->col != atual->col))
				{
					cont++;
					printf("cont = %d\n", cont);
				}
				aux2 = aux1;
				aux1 = aux1->next;
				auxvivo--;
				printf("auxvivo final %d\n",auxvivo);
				printf("\n\n acabou aqui\n\n");
			}
			printf("contador %d\n", cont);
			if (cont < 2)
			{
				printf("%d, %d\n", atual->lin, atual->col);
				vida[atual->lin][atual->col] = '.';
			}
			else if (cont == 2 || cont == 3)
			{
				carregaGeracao(atual->lin, atual->col);
			}
			else 
			{
				printf("%d, %d\n", atual->lin, atual->col);
				vida[atual->lin][atual->col] = '.';
			}
			
			atual = atual->next;
			//printf("Nova Cel a ser comparada %d %d\n", atual->lin, atual->col);
			auxvivoDentro--;
		//	printf("\n\nprox etapa\n");
		}
		
		
//	}
	
}

//carrega celulas que nasceram na lista da proxima geracao
void carregaGeracao(int ii, int jj)
{
	//cria lista de celulas que nasceram
	tipoCel *auxGeracao = malloc(sizeof(tipoCel));
	if (auxGeracao == NULL)
	{
		mensagem(1);
	}
	
	auxGeracao->lin = ii;
	auxGeracao->col = jj;
	
	if (totgeracao == 0)
	{
		pgeracao = auxGeracao;
		pgeracao->next = NULL;
	}
	else
	{
		auxGeracao->next = pgeracao;
		pgeracao = auxGeracao;
		
	}
	if (vida[ii][jj] == '.')
	{
		vida[pgeracao->lin][pgeracao->col] = '+';
	}
	
	totgeracao++;
}

void teste()
{

		limpaListaVivo();
		carregaMortosVizinhos();

		printf("oi?????????\n");
		
		printf("e aq?\n");
		limpaListaMorto();
		printf("alou???\n");
	
	if (totgeracao != 0)
	{
		tipoCel *aux1;
		printf("entra1\n");
		aux1 = pgeracao;
		printf("oi\n");
		int linha = aux1->lin;
		int coluna = aux1->col;
		printf("%d,%d\n\n", linha, coluna);

	

		printf("totgeracao: %d\n", totgeracao);
	
		while (totgeracao != 0)
		{
			printf("entra2\n");
			printf("coordenada da lista: %d,%d\n\n", aux1->lin, aux1->col);
			carregaVivo(aux1->lin, aux1->col);
			printf("entra3\n");
			aux1 = aux1->next;
			printf("entra4\n");
			totgeracao--;
		}
	
	
	}

		carregaMortosVizinhos();
		limpaListaGeracao();
		
	
}
