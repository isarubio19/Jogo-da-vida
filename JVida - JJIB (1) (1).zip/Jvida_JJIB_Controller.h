/*Jvida_JJIB_Controller.h
Beatriz Lopes Rizzo, Julia Gachido Schmidt, Joao Pedro Figols Neco, Isabella Rubio Venancio*/

void geraMatriz();
void inicializaMenu();
void carregaVivo(int ii, int jj);
void removeVivo(int ii, int jj);
void carregaMortosVizinhos();
void descobreCoord(int lin, int col);
void limpaListaMorto();
void limpaListaVivo();
int verifica1Morto(int ii, int jj);
void gravaCelulas();
void recuperaCelulas();
void proxGeracao();
void carregaGeracao(int ii, int jj);
void teste();
void limpaListaGeracao();

