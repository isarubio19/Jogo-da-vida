/*Jvida_JJIB_View.h
Beatriz Lopes Rizzo, Julia Gachido Schmidt, Joao Pedro Figols Neco, Isabella Rubio Venancio*/

int tamanho();
int menuPrincipal();
void geraVida();
void flush_in();
void coordCelula();
void mostraListVivo();
void mostraListMorto();
void mostraListGer();
void mensagem(int msg);


